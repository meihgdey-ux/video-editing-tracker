# Video Editing Tracker

A job, payout and invoice tracker for a small video editing team. Replaces the Google Sheet while keeping the same workflow: take a job, assign an editor, move it through statuses, then bill the client.

## Run it

Requires Node 18 or newer.

```bash
npm install
npm run dev
```

Opens at `http://localhost:5173`.

```bash
npm run build     # production build into dist/
npm run preview   # serve the production build locally
```

## The two money numbers

These are separate on purpose and never derived from each other.

| | What it is | Currency | Who sees it |
|---|---|---|---|
| **Budget** | What you pay the editor | VNĐ | Admin and the assigned editor |
| **Invoice price** | What you charge the client | USD | Admin only |

A job can cost you 520,000₫ in editor pay and be billed at $80. Changing one never moves the other.

Budget is itemised — Edit, Subtext Caption, AI Effect and so on — and the total is summed for you. The default price per item lives in Settings → Budget rate card.

## Roles

Switch between them in the sidebar under **View as**.

**Admin** sees everything: dashboard, all jobs, every editor's earnings, invoices, and settings.

**Editor** sees only jobs assigned to them, their own earnings, and their own budget. Invoices, the financial dashboard, other editors' pay, CS name and job type are all hidden.

> **This is a UI-level split, not authentication.** Anyone using the app can switch to Admin. It stops an editor from *stumbling into* client pricing; it does not stop someone who wants to look. Real enforcement needs a backend with accounts — see below.

## Statuses

`Pending → In Progress → Review → Revision → Done → Delivered → Paid`

Change a status straight from the dropdown in the jobs table. It saves immediately, no edit-then-save round trip.

## Invoices

An invoice groups several of one client's jobs. Pick the client, tick the jobs, and it totals the invoice prices for you.

**Sent** and **Paid** are independent toggles, each recording its own date, because a sent invoice isn't a paid one.

Each invoice **stores the exchange rate it was created with**. Updating the rate in Settings changes future conversions only — historical invoice totals never shift underneath you.

## Importing from Google Sheets

Settings → **Import jobs**.

1. Select the rows in your sheet and copy them (Ctrl/Cmd+C).
2. Paste into the box.
3. Check the column mapping it guessed, fix anything wrong, then import.

Nothing is written until you confirm the mapping.

Handled for you:

- Multi-line cells (long instructions) stay in one cell instead of splitting into rows
- Both tab-separated (a Sheets copy) and comma-separated (a CSV export) input
- Amounts with thousands separators, like `1,120`
- A **day/month/year** toggle — tick it if `04/07/2026` means 4 July in your sheet
- Job codes that already exist are skipped, so re-importing won't duplicate anything
- Unrecognised clients and editors are added to your lists automatically

`sample-import.csv` in the project root is a small working example.

## Sharing data across the team

**By default this app stores data in `localStorage`, which is per-browser.** Each person sees only what they typed. That is fine for evaluating the app and wrong for a shared tracker — so plan on replacing it before the team relies on it.

Everything goes through one module: `src/lib/storage.js`. Nothing else touches a storage engine. Swap the `engine` object in that file for calls to your API (or Supabase, Firebase, a Postgres endpoint — anything with get/set/remove/keys) and the rest of the app needs no changes.

`storage.exportAll()` and `storage.importAll()` are there for backups and for moving data when you migrate.

## Project layout

```
src/
├── main.jsx                  entry point
├── App.jsx                   shell: routing, role, theme, data loading
├── index.css                 global reset and font setup
├── lib/
│   ├── theme.js              dark/light tokens, fonts, theme context
│   ├── domain.js             job model, statuses, money and date helpers
│   ├── importer.js           delimited-text parser and column guessing
│   └── storage.js            the one seam to a backend
└── components/
    ├── primitives.jsx        buttons, inputs, cards, badges, modal
    ├── Dashboard.jsx         stats, revenue chart, client/editor breakdown
    ├── JobsView.jsx          job table, filters, inline status editing
    ├── JobDrawer.jsx         create, view and edit a job
    ├── EditorsView.jsx       per-editor earnings
    ├── InvoicesView.jsx      invoice list, builder and detail
    ├── ImportModal.jsx       Google Sheets import flow
    └── SettingsView.jsx      rate, clients, editors, rate card
```

## Editing clients, editors and prices

All in Settings, all admin-only.

**Renaming cascades.** Rename an editor from `TE` to `TE Cuong` and every job assigned to them updates too. Deleting is blocked while a name is still in use — rename instead, so no job is left pointing at someone who no longer exists.

Changing a price on the rate card affects **new** budget lines only. Jobs already saved keep the amount they were created with, so past payouts stay accurate.
