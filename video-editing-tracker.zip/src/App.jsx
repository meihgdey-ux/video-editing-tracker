import { useState, useEffect, useMemo, createContext, useContext } from "react";
import {
  LayoutDashboard, ListTodo, Users, Receipt, Settings, Plus, X, Sun, Moon,
  AlertTriangle, Menu, Circle, Wallet,
} from "lucide-react";
import { makeTokens, ThemeCtx, useT, SANS, MONO, ensureFonts } from "./lib/theme.js";
import {
  DEFAULT_EDITORS, DEFAULT_CLIENTS, DEFAULT_RATES,
  emptyJob, nextJobCode, monthKey, monthName,
} from "./lib/domain.js";
import { storage } from "./lib/storage.js";
import { Btn, Select, Card, Skeleton } from "./components/primitives.jsx";
import { Dashboard } from "./components/Dashboard.jsx";
import { JobsView } from "./components/JobsView.jsx";
import { EditorsView, EarningsView } from "./components/EditorsView.jsx";
import { InvoicesView, InvoiceDetail } from "./components/InvoicesView.jsx";
import { JobDrawer } from "./components/JobDrawer.jsx";
import { SettingsView } from "./components/SettingsView.jsx";
import { ImportModal } from "./components/ImportModal.jsx";

const NAV_ADMIN = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "jobs", label: "Jobs", icon: ListTodo },
  { key: "editors", label: "Editors", icon: Users },
  { key: "invoices", label: "Invoices", icon: Receipt },
  { key: "settings", label: "Settings", icon: Settings },
];
const NAV_EDITOR = [
  { key: "jobs", label: "My jobs", icon: ListTodo },
  { key: "earnings", label: "My earnings", icon: Wallet },
];

export default function App() {
  const [mode, setMode] = useState("dark");
  const T = useMemo(() => makeTokens(mode), [mode]);

  const [role, setRole] = useState("admin");
  const [me, setMe] = useState(DEFAULT_EDITORS[0]);
  const [view, setView] = useState("dashboard");
  const [navOpen, setNavOpen] = useState(false);

  const [jobs, setJobs] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [config, setConfig] = useState({
    exchangeRate: 25950,
    clients: DEFAULT_CLIENTS,
    editors: DEFAULT_EDITORS,
    rates: DEFAULT_RATES,
    invoiceSeq: 1,
  });
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const [month, setMonth] = useState("ALL");
  const [drawer, setDrawer] = useState(null);
  const [openInvoice, setOpenInvoice] = useState(null);
  const [importOpen, setImportOpen] = useState(false);

  useEffect(ensureFonts, []);

  useEffect(() => {
    (async () => {
      try {
        const c = await storage.getConfig();
        if (c) setConfig((p) => ({ ...p, ...c }));
      } catch {}
      try {
        setJobs(await storage.listJobs());
      } catch { setErr("Couldn't load jobs. Reload to try again."); }
      try {
        setInvoices(await storage.listInvoices());
      } catch {}
      setLoading(false);
    })();
  }, []);

  const saveConfig = async (patch) => {
    const next = { ...config, ...patch };
    setConfig(next);
    try { await storage.setConfig(next); } catch { setErr("Couldn't save settings."); }
  };

  const putJob = async (job) => {
    setJobs((p) => {
      const i = p.findIndex((x) => x.jobCode === job.jobCode);
      return i >= 0 ? [...p.slice(0, i), job, ...p.slice(i + 1)] : [...p, job];
    });
    try { await storage.saveJob(job); }
    catch { setErr("Couldn't save the job. Check your connection and try again."); }
  };
  const patchJob = async (code, patch) => {
    const j = jobs.find((x) => x.jobCode === code);
    if (j) await putJob({ ...j, ...patch });
  };
  const removeJob = async (code) => {
    setJobs((p) => p.filter((x) => x.jobCode !== code));
    try { await storage.deleteJob(code); } catch {}
  };
  const putInvoice = async (inv) => {
    setInvoices((p) => {
      const i = p.findIndex((x) => x.id === inv.id);
      return i >= 0 ? [...p.slice(0, i), inv, ...p.slice(i + 1)] : [...p, inv];
    });
    try { await storage.saveInvoice(inv); }
    catch { setErr("Couldn't save the invoice."); }
  };
  const removeInvoice = async (inv) => {
    setInvoices((p) => p.filter((x) => x.id !== inv.id));
    try { await storage.deleteInvoice(inv.id); } catch {}
    for (const code of inv.jobCodes) await patchJob(code, { invoiceId: null });
  };

  const renameAcross = async (field, from, to) => {
    const listKey = field === "client" ? "clients" : "editors";
    await saveConfig({ [listKey]: config[listKey].map((x) => (x === from ? to : x)) });
    if (role === "editor" && field === "assignedEditor" && me === from) setMe(to);
    const touched = jobs.filter((j) => j[field] === from);
    const updated = touched.map((j) => ({ ...j, [field]: to }));
    setJobs((p) => p.map((j) => (j[field] === from ? { ...j, [field]: to } : j)));
    for (const j of updated) {
      try { await storage.saveJob(j); }
      catch { setErr(`Renamed, but couldn't update job ${j.jobCode}.`); }
    }
  };

  const importJobs = async (rows) => {
    setJobs((p) => [...p, ...rows]);
    const newClients = Array.from(new Set(rows.map((r) => r.client).filter((c) => c && !config.clients.includes(c))));
    const newEditors = Array.from(new Set(rows.map((r) => r.assignedEditor).filter((e) => e && !config.editors.includes(e))));
    if (newClients.length || newEditors.length) {
      await saveConfig({ clients: [...config.clients, ...newClients], editors: [...config.editors, ...newEditors] });
    }
    let failed = 0;
    for (const j of rows) {
      try { await storage.saveJob(j); } catch { failed++; }
    }
    setImportOpen(false);
    if (failed) setErr(`${rows.length - failed} of ${rows.length} jobs imported. ${failed} failed to save — try importing those again.`);
  };

  const months = useMemo(
    () => Array.from(new Set(jobs.map((j) => monthKey(j.date)).filter(Boolean))).sort().reverse(),
    [jobs]
  );

  const visibleJobs = useMemo(
    () => (role === "admin" ? jobs : jobs.filter((j) => j.assignedEditor === me)),
    [jobs, role, me]
  );
  const scoped = useMemo(
    () => (month === "ALL" ? visibleJobs : visibleJobs.filter((j) => monthKey(j.date) === month)),
    [visibleJobs, month]
  );

  const nav = role === "admin" ? NAV_ADMIN : NAV_EDITOR;
  useEffect(() => { if (!nav.some((n) => n.key === view)) setView(nav[0].key); }, [role]);

  return (
    <ThemeCtx.Provider value={T}>
      <style>{`
        @keyframes vtPulse{0%,100%{opacity:.5}50%{opacity:.85}}
        @keyframes vtIn{from{opacity:0;transform:translateY(6px) scale(.99)}to{opacity:1;transform:none}}
        @media (prefers-reduced-motion: reduce){*{animation:none!important;transition:none!important}}
        .vt-scroll::-webkit-scrollbar{height:9px;width:9px}
        .vt-scroll::-webkit-scrollbar-thumb{background:${T.borderStrong};border-radius:9px}
        .vt-scroll::-webkit-scrollbar-track{background:transparent}
        .vt-row:hover{background:${T.surface2}}
        .vt-nav{display:none}
        .vt-nav-open{
          display:flex;position:fixed;top:0;bottom:0;left:0;z-index:70;
          box-shadow:0 0 40px rgba(0,0,0,.4);
        }
        .vt-scrim{position:fixed;inset:0;z-index:69;background:rgba(8,10,14,.5)}
        @media (min-width:900px){
          .vt-nav{display:flex;position:static;box-shadow:none}
          .vt-scrim{display:none}
          .vt-menu-btn{display:none!important}
        }
        @media print{.vt-noprint{display:none!important}}
      `}</style>

      <div style={{
        display: "flex", minHeight: 720, fontFamily: SANS, fontSize: 14, lineHeight: 1.5,
        background: T.bg, color: T.text, borderRadius: 14, overflow: "hidden", border: `1px solid ${T.border}`,
      }}>
        {/* sidebar */}
        {navOpen && <div className="vt-scrim vt-noprint" onClick={() => setNavOpen(false)} />}
        <aside className={`vt-nav vt-noprint${navOpen ? " vt-nav-open" : ""}`} style={{
          width: 216, flexShrink: 0, background: T.surface, borderRight: `1px solid ${T.border}`,
          flexDirection: "column",
        }}>
          <SidebarInner {...{ nav, view, setView, role, setRole, me, setMe, mode, setMode, editors: config.editors, onClose: () => setNavOpen(false) }} />
        </aside>

        {/* main */}
        <main style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
          <header className="vt-noprint" style={{
            display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12,
            padding: "13px 18px", borderBottom: `1px solid ${T.border}`, background: T.surface,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
              <Btn variant="subtle" className="vt-menu-btn" onClick={() => setNavOpen((v) => !v)} style={{ padding: 6 }}><Menu size={18} /></Btn>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 15, letterSpacing: "-.01em" }}>
                  {nav.find((n) => n.key === view)?.label}
                </div>
                <div style={{ fontSize: 12, color: T.faint, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {role === "admin" ? "Admin" : me} · {month === "ALL" ? "All months" : monthName(month)}
                </div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Select value={month} onChange={(e) => setMonth(e.target.value)} style={{ width: 158 }}>
                <option value="ALL">All months</option>
                {months.map((m) => <option key={m} value={m}>{monthName(m)}</option>)}
              </Select>
              {role === "admin" && (
                <Btn variant="primary" onClick={() => setDrawer({ mode: "new", job: { ...emptyJob(config.rates), jobCode: nextJobCode(jobs) } })}>
                  <Plus size={15} /> New job
                </Btn>
              )}
            </div>
          </header>

          {err && (
            <div style={{ margin: "12px 18px 0", padding: "10px 13px", borderRadius: 8, display: "flex", gap: 8, alignItems: "center",
              background: `${T.bad}14`, border: `1px solid ${T.bad}44`, color: T.bad, fontSize: 13 }}>
              <AlertTriangle size={15} /> {err}
              <Btn variant="subtle" onClick={() => setErr("")} style={{ marginLeft: "auto", padding: 4, color: T.bad }}><X size={14} /></Btn>
            </div>
          )}

          <div className="vt-scroll" style={{ flex: 1, overflow: "auto", padding: 18 }}>
            {loading ? (
              <LoadingState />
            ) : view === "dashboard" ? (
              <Dashboard jobs={scoped} invoices={invoices} rate={config.exchangeRate} month={month} />
            ) : view === "jobs" ? (
              <JobsView
                jobs={scoped} role={role} clients={config.clients}
                onOpen={(j) => setDrawer({ mode: "view", job: j })}
                onStatus={(code, s) => patchJob(code, { status: s })}
                onNew={() => setDrawer({ mode: "new", job: { ...emptyJob(config.rates), jobCode: nextJobCode(jobs) } })}
              />
            ) : view === "editors" ? (
              <EditorsView jobs={scoped} rate={config.exchangeRate} editors={config.editors} />
            ) : view === "earnings" ? (
              <EarningsView jobs={scoped} me={me} rate={config.exchangeRate} />
            ) : view === "invoices" ? (
              <InvoicesView
                jobs={jobs} invoices={invoices} config={config} month={month} months={months}
                onOpen={setOpenInvoice} onCreate={putInvoice} onPatchJob={patchJob}
                onBumpSeq={(n) => saveConfig({ invoiceSeq: n })}
              />
            ) : (
              <SettingsView
                config={config} onSave={saveConfig} jobs={jobs}
                onRenameAcross={renameAcross} onImport={() => setImportOpen(true)}
              />
            )}
          </div>
        </main>
      </div>

      {drawer && (
        <JobDrawer
          drawer={drawer} role={role} clients={config.clients} editors={config.editors} rates={config.rates} rate={config.exchangeRate}
          existing={jobs.map((j) => j.jobCode)}
          onClose={() => setDrawer(null)}
          onSave={async (j) => { await putJob(j); setDrawer(null); }}
          onDelete={async (c) => { await removeJob(c); setDrawer(null); }}
        />
      )}
      {openInvoice && (
        <InvoiceDetail
          invoice={openInvoice} jobs={jobs} onClose={() => setOpenInvoice(null)}
          onUpdate={async (inv) => { await putInvoice(inv); setOpenInvoice(inv); }}
          onDelete={async (inv) => { await removeInvoice(inv); setOpenInvoice(null); }}
        />
      )}
      {importOpen && (
        <ImportModal
          onClose={() => setImportOpen(false)}
          onImport={importJobs}
          existingCodes={jobs.map((j) => j.jobCode)}
          rates={config.rates}
        />
      )}
    </ThemeCtx.Provider>
  );
}

export function SidebarInner({ nav, view, setView, role, setRole, me, setMe, mode, setMode, editors, onClose }) {
  const T = useT();
  return (
    <>
      <div style={{ padding: "16px 14px 12px", display: "flex", alignItems: "center", gap: 9 }}>
        <div style={{ width: 30, height: 30, borderRadius: 8, background: T.accent, display: "grid", placeItems: "center" }}>
          <Circle size={13} color={T.accentText} strokeWidth={3} />
        </div>
        <div style={{ fontWeight: 800, fontSize: 14.5, letterSpacing: "-.01em" }}>Edit Tracker</div>
        {onClose && <Btn variant="subtle" className="vt-menu-btn" onClick={onClose} style={{ marginLeft: "auto", padding: 4 }}><X size={16} /></Btn>}
      </div>

      <nav style={{ padding: "4px 8px", display: "flex", flexDirection: "column", gap: 2 }}>
        {nav.map((n) => {
          const on = view === n.key;
          return (
            <button key={n.key} onClick={() => { setView(n.key); onClose?.(); }} style={{
              display: "flex", alignItems: "center", gap: 9, width: "100%", textAlign: "left",
              padding: "8px 10px", borderRadius: 8, cursor: "pointer", fontSize: 13.5, fontWeight: on ? 650 : 500,
              background: on ? T.surface2 : "transparent", color: on ? T.text : T.muted, border: "none",
              fontFamily: SANS,
            }}>
              <n.icon size={16} strokeWidth={on ? 2.4 : 2} color={on ? T.accent : T.faint} />
              {n.label}
            </button>
          );
        })}
      </nav>

      <div style={{ marginTop: "auto", padding: 12, borderTop: `1px solid ${T.border}`, display: "flex", flexDirection: "column", gap: 10 }}>
        <div>
          <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: ".06em", textTransform: "uppercase", color: T.faint, marginBottom: 6 }}>View as</div>
          <div style={{ display: "flex", background: T.surface2, borderRadius: 8, padding: 3, gap: 2 }}>
            {["admin", "editor"].map((r) => (
              <button key={r} onClick={() => setRole(r)} style={{
                flex: 1, padding: "5px 0", borderRadius: 6, border: "none", cursor: "pointer",
                fontSize: 12, fontWeight: 700, fontFamily: SANS, textTransform: "capitalize",
                background: role === r ? T.accent : "transparent", color: role === r ? T.accentText : T.muted,
              }}>{r}</button>
            ))}
          </div>
        </div>
        {role === "editor" && (
          <Select value={me} onChange={(e) => setMe(e.target.value)} style={{ fontSize: 12.5, padding: "7px 9px" }}>
            {editors.map((e) => <option key={e}>{e}</option>)}
          </Select>
        )}
        <Btn variant="ghost" onClick={() => setMode(mode === "dark" ? "light" : "dark")} style={{ justifyContent: "flex-start" }}>
          {mode === "dark" ? <Sun size={15} /> : <Moon size={15} />} {mode === "dark" ? "Light mode" : "Dark mode"}
        </Btn>
      </div>
    </>
  );
}

function LoadingState() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(170px,1fr))", gap: 12 }}>
        {[0, 1, 2, 3].map((i) => <Card key={i}><Skeleton h={11} w="55%" /><div style={{ height: 10 }} /><Skeleton h={22} w="70%" /></Card>)}
      </div>
      <Card><Skeleton h={200} /></Card>
    </div>
  );
}
