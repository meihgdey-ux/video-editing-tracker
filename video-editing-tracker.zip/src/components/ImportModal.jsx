import { useState, useMemo } from "react";
import { Upload, AlertTriangle } from "lucide-react";
import { useT, MONO } from "../lib/theme.js";
import { STATUSES, emptyJob, nextId } from "../lib/domain.js";
import { parseDelimited, IMPORT_FIELDS, guessField, parseMoney, normalizeDate } from "../lib/importer.js";
import { Modal, Btn, Select, TextArea } from "./primitives.jsx";

export function ImportModal({ onClose, onImport, existingCodes, rates }) {
  const T = useT();
  const [text, setText] = useState("");
  const [hasHeader, setHasHeader] = useState(true);
  const [dayFirst, setDayFirst] = useState(false);
  const [map, setMap] = useState([]);
  const [step, setStep] = useState(1);

  const rows = useMemo(() => (text.trim() ? parseDelimited(text) : []), [text]);
  const header = hasHeader && rows.length ? rows[0] : [];
  const body = hasHeader ? rows.slice(1) : rows;

  const analyse = () => {
    const cols = Math.max(...rows.map((r) => r.length), 0);
    const guessed = Array.from({ length: cols }, (_, i) => (hasHeader ? guessField(header[i] || "") : "skip"));
    setMap(guessed);
    setStep(2);
  };

  const built = useMemo(() => {
    if (step < 2) return [];
    const out = [];
    const seen = new Set(existingCodes);
    body.forEach((r, ri) => {
      const j = { ...emptyJob(rates), budgetItems: [] };
      let budget = 0;
      map.forEach((field, ci) => {
        const v = (r[ci] ?? "").trim();
        if (!v || field === "skip") return;
        if (field === "budget") budget = parseMoney(v);
        else if (field === "invoicePrice") j.invoicePrice = String(parseMoney(v));
        else if (field === "date") {
          let s = v;
          if (dayFirst) {
            const m = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
            if (m) s = `${m[2]}/${m[1]}/${m[3]}`;
          }
          j.date = normalizeDate(s) || j.date;
        } else j[field] = v;
      });
      j.budgetItems = [{ id: nextId("b"), label: "Edit", amount: budget }];
      if (!j.jobCode) j.jobCode = `IMP-${Date.now().toString(36)}-${ri}`;
      if (!STATUSES.includes(j.status)) j.status = "Pending";
      const dup = seen.has(j.jobCode);
      seen.add(j.jobCode);
      out.push({ job: j, dup });
    });
    return out;
  }, [step, map, body, dayFirst, existingCodes, rates]);

  const fresh = built.filter((b) => !b.dup);
  const dups = built.length - fresh.length;
  const mapped = map.filter((m) => m !== "skip").length;

  return (
    <Modal
      title="Import jobs" icon={<Upload size={17} color={T.accent} />} onClose={onClose} width={860}
      footer={
        step === 1 ? (
          <>
            <Btn onClick={onClose}>Cancel</Btn>
            <Btn variant="primary" disabled={!rows.length} onClick={analyse}>Continue · {rows.length} rows</Btn>
          </>
        ) : (
          <>
            <Btn onClick={() => setStep(1)}>Back</Btn>
            <div style={{ flex: 1 }} />
            <Btn variant="primary" disabled={!fresh.length} onClick={() => onImport(fresh.map((b) => b.job))}>
              Import {fresh.length} jobs
            </Btn>
          </>
        )
      }
    >
      {step === 1 ? (
        <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
          <div style={{ fontSize: 13, color: T.muted }}>
            In Google Sheets, select the rows you want, press Ctrl/Cmd+C, then paste into the box below. Nothing is saved until you confirm the column mapping on the next step.
          </div>
          <TextArea
            value={text} onChange={(e) => setText(e.target.value)} style={{ minHeight: 220, fontFamily: MONO, fontSize: 12 }}
            placeholder={"DATE\tCUS\tJOB CODE\tINSTRUCTION\t...\n01/08/2026\tBrock\tMHAUG001\t..."}
          />
          <label style={{ display: "flex", alignItems: "center", gap: 9, fontSize: 13.5, cursor: "pointer" }}>
            <input type="checkbox" checked={hasHeader} onChange={(e) => setHasHeader(e.target.checked)} />
            First row is a header
          </label>
          <label style={{ display: "flex", alignItems: "center", gap: 9, fontSize: 13.5, cursor: "pointer" }}>
            <input type="checkbox" checked={dayFirst} onChange={(e) => setDayFirst(e.target.checked)} />
            Dates are day/month/year (e.g. 04/07/2026 means 4 July)
          </label>
          {rows.length > 0 && (
            <div style={{ fontSize: 13, color: T.good }}>
              Found {rows.length} rows × {Math.max(...rows.map((r) => r.length))} columns.
            </div>
          )}
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 13 }}>
          <div style={{ fontSize: 13, color: T.muted }}>
            Match each column to a field. Anything set to Skip is ignored.
          </div>
          <div className="vt-scroll" style={{ overflowX: "auto", border: `1px solid ${T.border}`, borderRadius: 10 }}>
            <table style={{ borderCollapse: "collapse", fontSize: 12.5 }}>
              <thead>
                <tr>
                  {map.map((f, i) => (
                    <th key={i} style={{ padding: 8, borderBottom: `1px solid ${T.border}`, background: T.surface2, minWidth: 150 }}>
                      <Select value={f} onChange={(e) => setMap((m) => m.map((x, k) => (k === i ? e.target.value : x)))} style={{ fontSize: 12, padding: "6px 8px" }}>
                        {IMPORT_FIELDS.map((o) => <option key={o.key} value={o.key}>{o.label}</option>)}
                      </Select>
                      {hasHeader && (
                        <div style={{ marginTop: 5, color: T.faint, fontSize: 11, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {header[i] || "(no header)"}
                        </div>
                      )}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {body.slice(0, 4).map((r, ri) => (
                  <tr key={ri}>
                    {map.map((_, ci) => (
                      <td key={ci} style={{ padding: "7px 8px", borderTop: `1px solid ${T.border}`, color: T.muted, maxWidth: 190, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {(r[ci] ?? "").trim() || "—"}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ display: "flex", gap: 18, flexWrap: "wrap", fontSize: 13 }}>
            <span><b style={{ fontFamily: MONO }}>{fresh.length}</b> jobs ready</span>
            <span style={{ color: T.muted }}><b style={{ fontFamily: MONO }}>{mapped}</b> columns mapped</span>
            {dups > 0 && <span style={{ color: T.warn }}><b style={{ fontFamily: MONO }}>{dups}</b> skipped — job code already exists</span>}
          </div>

          {mapped === 0 && (
            <div style={{ fontSize: 13, color: T.warn, display: "flex", gap: 7, alignItems: "center" }}>
              <AlertTriangle size={14} /> Map at least one column before importing.
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}
