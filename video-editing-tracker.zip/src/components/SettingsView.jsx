import { useState } from "react";
import { Check, X, Trash2, Pencil, Upload } from "lucide-react";
import { useT, MONO } from "../lib/theme.js";
import { Card, Btn, TextInput, Field, ClientBadge, Avatar } from "./primitives.jsx";

export function EditableList({ title, blurb, items, jobs, jobField, onChange, onRename, renderBadge }) {
  const T = useT();
  const [adding, setAdding] = useState("");
  const [editIdx, setEditIdx] = useState(-1);
  const [draft, setDraft] = useState("");

  const usage = (name) => jobs.filter((j) => j[jobField] === name).length;

  const commit = (i) => {
    const name = draft.trim();
    const old = items[i];
    if (!name || name === old) { setEditIdx(-1); return; }
    if (items.some((x, k) => k !== i && x === name)) { setEditIdx(-1); return; }
    onRename(old, name);
    setEditIdx(-1);
  };

  return (
    <Card>
      <div style={{ fontWeight: 650, marginBottom: 4 }}>{title}</div>
      <div style={{ color: T.muted, fontSize: 13, marginBottom: 12 }}>{blurb}</div>

      <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 12 }}>
        {items.length === 0 && <div style={{ color: T.faint, fontSize: 13 }}>Nothing here yet.</div>}
        {items.map((name, i) => {
          const n = usage(name);
          return (
            <div key={name} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderTop: i ? `1px solid ${T.border}` : "none" }}>
              {editIdx === i ? (
                <>
                  <TextInput
                    autoFocus value={draft} onChange={(e) => setDraft(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") commit(i); if (e.key === "Escape") setEditIdx(-1); }}
                  />
                  <Btn variant="primary" onClick={() => commit(i)} style={{ padding: "7px 11px" }}><Check size={14} /></Btn>
                  <Btn variant="subtle" onClick={() => setEditIdx(-1)} style={{ padding: 6 }}><X size={15} /></Btn>
                </>
              ) : (
                <>
                  <div style={{ flex: 1, minWidth: 0 }}>{renderBadge(name)}</div>
                  <span style={{ fontFamily: MONO, fontSize: 12, color: T.faint }}>{n} jobs</span>
                  <Btn variant="subtle" title="Rename" onClick={() => { setEditIdx(i); setDraft(name); }} style={{ padding: 5 }}>
                    <Pencil size={13} />
                  </Btn>
                  <Btn
                    variant="subtle" title={n ? "Used by jobs — rename instead" : "Remove"} disabled={!!n}
                    onClick={() => onChange(items.filter((x) => x !== name))} style={{ padding: 5 }}
                  >
                    <Trash2 size={13} />
                  </Btn>
                </>
              )}
            </div>
          );
        })}
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <TextInput
          value={adding} onChange={(e) => setAdding(e.target.value)} placeholder="Add new"
          onKeyDown={(e) => {
            if (e.key === "Enter" && adding.trim() && !items.includes(adding.trim())) {
              onChange([...items, adding.trim()]); setAdding("");
            }
          }}
        />
        <Btn variant="primary" disabled={!adding.trim() || items.includes(adding.trim())}
          onClick={() => { onChange([...items, adding.trim()]); setAdding(""); }}>Add</Btn>
      </div>
    </Card>
  );
}

export function RateList({ rates, onSave }) {
  const T = useT();
  const [adding, setAdding] = useState("");

  const upd = (i, patch) => onSave({ rates: rates.map((r, k) => (k === i ? { ...r, ...patch } : r)) });

  return (
    <Card>
      <div style={{ fontWeight: 650, marginBottom: 4 }}>Budget rate card</div>
      <div style={{ color: T.muted, fontSize: 13, marginBottom: 12 }}>
        Default pay per line item. Changing a price here only affects new budget lines — jobs already created keep what they were saved with.
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 7, marginBottom: 12 }}>
        {rates.map((r, i) => (
          <div key={r.label} style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <TextInput value={r.label} onChange={(e) => upd(i, { label: e.target.value })} style={{ flex: 2 }} />
            <TextInput type="number" value={r.price} onChange={(e) => upd(i, { price: parseFloat(e.target.value) || 0 })} style={{ flex: 1 }} />
            <Btn variant="subtle" onClick={() => onSave({ rates: rates.filter((_, k) => k !== i) })} style={{ padding: 5 }}>
              <Trash2 size={13} />
            </Btn>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <TextInput value={adding} onChange={(e) => setAdding(e.target.value)} placeholder="Add a line item" />
        <Btn variant="primary" disabled={!adding.trim() || rates.some((r) => r.label === adding.trim())}
          onClick={() => { onSave({ rates: [...rates, { label: adding.trim(), price: 0 }] }); setAdding(""); }}>Add</Btn>
      </div>
    </Card>
  );
}

export function SettingsView({ config, onSave, jobs, onRenameAcross, onImport }) {
  const T = useT();
  const [rate, setRate] = useState(String(config.exchangeRate));
  const [saved, setSaved] = useState(false);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(320px,1fr))", gap: 12, alignItems: "start" }}>
      <Card>
        <div style={{ fontWeight: 650, marginBottom: 4 }}>PayPal exchange rate</div>
        <div style={{ color: T.muted, fontSize: 13, marginBottom: 12 }}>
          Converts USD to VNĐ across the app. Invoices keep the rate they were created with, so past totals never shift.
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
          <Field label="1 USD ="><TextInput type="number" value={rate} onChange={(e) => setRate(e.target.value)} /></Field>
          <Btn variant="primary" onClick={async () => { await onSave({ exchangeRate: parseFloat(rate) || 0 }); setSaved(true); setTimeout(() => setSaved(false), 1500); }}>
            {saved ? <Check size={14} /> : null} {saved ? "Saved" : "Save rate"}
          </Btn>
        </div>
        <div style={{ marginTop: 10, fontFamily: MONO, fontSize: 12.5, color: T.muted }}>
          $1 = {(parseFloat(rate) || 0).toLocaleString("vi-VN")}₫
        </div>
      </Card>

      <Card>
        <div style={{ fontWeight: 650, marginBottom: 4 }}>Import from Google Sheets</div>
        <div style={{ color: T.muted, fontSize: 13, marginBottom: 12 }}>
          Select the rows in your sheet, copy them, and paste here. You choose which column maps to which field before anything is saved.
        </div>
        <Btn variant="primary" onClick={onImport}><Upload size={14} /> Import jobs</Btn>
      </Card>

      <EditableList
        title="Clients" blurb="Shown as a dropdown when creating a job. Renaming updates every job that uses the old name."
        items={config.clients} jobs={jobs} jobField="client"
        onChange={(clients) => onSave({ clients })}
        onRename={(from, to) => onRenameAcross("client", from, to)}
        renderBadge={(n) => <ClientBadge name={n} />}
      />

      <EditableList
        title="Editors" blurb="Who jobs can be assigned to. Renaming updates every job assigned to the old name."
        items={config.editors} jobs={jobs} jobField="assignedEditor"
        onChange={(editors) => onSave({ editors })}
        onRename={(from, to) => onRenameAcross("assignedEditor", from, to)}
        renderBadge={(n) => (
          <span style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13.5 }}><Avatar name={n} size={24} />{n}</span>
        )}
      />

      <RateList rates={config.rates} onSave={onSave} />
    </div>
  );
}
