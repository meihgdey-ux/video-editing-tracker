import { useState, useEffect } from "react";
import { Search, Plus, Receipt, Trash2, Check, Copy, Printer, Link2 } from "lucide-react";
import { useT, SANS, MONO } from "../lib/theme.js";
import { statusTone, invPrice, monthKey, monthName, nextId, fmtVND, fmtUSD } from "../lib/domain.js";
import { Card, Btn, TextInput, Select, Field, Modal, Pill, ClientBadge } from "./primitives.jsx";
import { Empty } from "./Dashboard.jsx";

export function InvoicesView({ jobs, invoices, config, month, months, onOpen, onCreate, onPatchJob, onBumpSeq }) {
  const T = useT();
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("ALL");
  const [fMonth, setFMonth] = useState("ALL");
  const [builder, setBuilder] = useState(false);

  const totalsOf = (inv) => {
    const list = jobs.filter((j) => inv.jobCodes.includes(j.jobCode));
    const usd = list.reduce((s, j) => s + invPrice(j), 0);
    return { count: list.length, usd, vnd: usd * inv.rate };
  };

  const rows = invoices
    .filter((inv) => {
      if (q.trim() && !inv.client.toLowerCase().includes(q.toLowerCase().trim())) return false;
      if (fMonth !== "ALL" && monthKey(inv.createdAt) !== fMonth) return false;
      if (filter === "Draft" && (inv.sentAt || inv.paidAt)) return false;
      if (filter === "Sent" && (!inv.sentAt || inv.paidAt)) return false;
      if (filter === "Paid" && !inv.paidAt) return false;
      return true;
    })
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  const th = { textAlign: "left", padding: "10px 12px", fontSize: 10.5, fontWeight: 700, letterSpacing: ".07em", color: T.faint, background: T.surface2, whiteSpace: "nowrap" };
  const td = { padding: "11px 12px", fontSize: 13 };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <div style={{ position: "relative", flex: "1 1 180px", minWidth: 160 }}>
          <Search size={14} color={T.faint} style={{ position: "absolute", left: 11, top: 11 }} />
          <TextInput value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search client…" style={{ paddingLeft: 32 }} />
        </div>
        <Select value={fMonth} onChange={(e) => setFMonth(e.target.value)} style={{ width: 152 }}>
          <option value="ALL">All months</option>
          {months.map((m) => <option key={m} value={m}>{monthName(m)}</option>)}
        </Select>
        <div style={{ display: "flex", background: T.surface2, borderRadius: 8, padding: 3, gap: 2 }}>
          {["ALL", "Draft", "Sent", "Paid"].map((f) => (
            <button key={f} onClick={() => setFilter(f)} style={{
              padding: "6px 12px", borderRadius: 6, border: "none", cursor: "pointer", fontFamily: SANS,
              fontSize: 12, fontWeight: 650,
              background: filter === f ? T.surface : "transparent", color: filter === f ? T.text : T.muted,
            }}>{f === "ALL" ? "All" : f}</button>
          ))}
        </div>
        <Btn variant="primary" onClick={() => setBuilder(true)}><Plus size={15} /> New invoice</Btn>
      </div>

      <Card pad={0} style={{ overflow: "hidden" }}>
        {rows.length === 0 ? (
          <Empty
            title={invoices.length ? "No invoices match these filters" : "No invoices yet"}
            body={invoices.length ? "Clear a filter to see more." : "Group a client's delivered jobs into an invoice to bill them."}
            action={!invoices.length ? <Btn variant="primary" onClick={() => setBuilder(true)}><Plus size={15} /> New invoice</Btn> : null}
          />
        ) : (
          <div className="vt-scroll" style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 700 }}>
              <thead>
                <tr>
                  <th style={th}>Invoice #</th><th style={th}>Client</th><th style={th}>Jobs</th>
                  <th style={{ ...th, textAlign: "right" }}>Total USD</th><th style={{ ...th, textAlign: "right" }}>Total VNĐ</th>
                  <th style={{ ...th, textAlign: "center" }}>Sent</th><th style={{ ...th, textAlign: "center" }}>Paid</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((inv) => {
                  const t = totalsOf(inv);
                  return (
                    <tr key={inv.id} className="vt-row" onClick={() => onOpen(inv)} style={{ borderTop: `1px solid ${T.border}`, cursor: "pointer", background: T.surface }}>
                      <td style={{ ...td, fontFamily: MONO, fontWeight: 650 }}>{inv.number}</td>
                      <td style={td}><ClientBadge name={inv.client} /></td>
                      <td style={{ ...td, color: T.muted }}>{t.count}</td>
                      <td style={{ ...td, textAlign: "right", fontFamily: MONO, fontWeight: 700 }}>{fmtUSD(t.usd)}</td>
                      <td style={{ ...td, textAlign: "right", fontFamily: MONO, color: T.muted }}>{fmtVND(t.vnd)}</td>
                      <td style={{ ...td, textAlign: "center" }}>{inv.sentAt ? <Pill tone="info" dot={false}>{inv.sentAt}</Pill> : <span style={{ color: T.faint }}>—</span>}</td>
                      <td style={{ ...td, textAlign: "center" }}>{inv.paidAt ? <Pill tone="good" dot={false}>{inv.paidAt}</Pill> : <span style={{ color: T.faint }}>—</span>}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {builder && (
        <InvoiceBuilder
          jobs={jobs} clients={config.clients} rate={config.exchangeRate} seq={config.invoiceSeq}
          onClose={() => setBuilder(false)}
          onCreate={async (inv) => {
            await onCreate(inv);
            for (const c of inv.jobCodes) await onPatchJob(c, { invoiceId: inv.id });
            await onBumpSeq(config.invoiceSeq + 1);
            setBuilder(false);
            onOpen(inv);
          }}
        />
      )}
    </div>
  );
}

export function InvoiceBuilder({ jobs, clients, rate, seq, onClose, onCreate }) {
  const T = useT();
  const withClients = clients.filter((c) => jobs.some((j) => j.client === c));
  const [client, setClient] = useState(withClients[0] || "");
  const [sel, setSel] = useState({});

  const candidates = jobs
    .filter((j) => j.client === client && !j.invoiceId)
    .sort((a, b) => (a.date || "").localeCompare(b.date || ""));

  useEffect(() => {
    const n = {};
    candidates.forEach((j) => (n[j.jobCode] = ["Done", "Delivered"].includes(j.status)));
    setSel(n);
  }, [client]);

  const picked = candidates.filter((j) => sel[j.jobCode]);
  const usd = picked.reduce((s, j) => s + invPrice(j), 0);

  return (
    <Modal title="New invoice" icon={<Receipt size={17} color={T.accent} />} onClose={onClose} width={720}
      footer={
        <>
          <Btn onClick={onClose}>Cancel</Btn>
          <Btn variant="primary" disabled={!picked.length}
            onClick={() => onCreate({
              id: nextId("inv"),
              number: `INV-${String(seq).padStart(4, "0")}`,
              client,
              jobCodes: picked.map((j) => j.jobCode),
              rate,
              createdAt: new Date().toISOString().slice(0, 10),
              sentAt: null,
              paidAt: null,
            })}>
            Create invoice · {fmtUSD(usd)}
          </Btn>
        </>
      }>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <Field label="Client">
          <Select value={client} onChange={(e) => setClient(e.target.value)}>
            {withClients.length === 0 && <option value="">No clients with jobs yet</option>}
            {withClients.map((c) => <option key={c}>{c}</option>)}
          </Select>
        </Field>

        {candidates.length === 0 ? (
          <Empty title="Nothing left to invoice" body="Every job for this client is already on an invoice." />
        ) : (
          <div style={{ border: `1px solid ${T.border}`, borderRadius: 10, overflow: "hidden" }}>
            {candidates.map((j) => (
              <label key={j.jobCode} style={{
                display: "grid", gridTemplateColumns: "22px 1fr 90px 88px", gap: 10, alignItems: "center",
                padding: "10px 12px", borderBottom: `1px solid ${T.border}`, cursor: "pointer", fontSize: 13,
              }}>
                <input type="checkbox" checked={!!sel[j.jobCode]} onChange={(e) => setSel((s) => ({ ...s, [j.jobCode]: e.target.checked }))} />
                <span style={{ minWidth: 0 }}>
                  <span style={{ fontFamily: MONO, fontSize: 11.5, color: T.muted }}>{j.jobCode}</span>
                  <div style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{j.jobName || "Untitled"}</div>
                </span>
                <Pill tone={statusTone[j.status]}>{j.status}</Pill>
                <span style={{ textAlign: "right", fontFamily: MONO, fontWeight: 650, color: invPrice(j) ? T.text : T.faint }}>
                  {invPrice(j) ? fmtUSD(invPrice(j)) : "no price"}
                </span>
              </label>
            ))}
          </div>
        )}

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <span style={{ color: T.muted, fontSize: 13 }}>{picked.length} jobs selected · rate {rate.toLocaleString("vi-VN")}</span>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: MONO, fontSize: 20, fontWeight: 800, color: T.accent }}>{fmtUSD(usd)}</div>
            <div style={{ fontFamily: MONO, fontSize: 12.5, color: T.muted }}>{fmtVND(usd * rate)}</div>
          </div>
        </div>
      </div>
    </Modal>
  );
}

export function InvoiceDetail({ invoice, jobs, onClose, onUpdate, onDelete }) {
  const T = useT();
  const [copied, setCopied] = useState(false);
  const list = jobs.filter((j) => invoice.jobCodes.includes(j.jobCode));
  const usd = list.reduce((s, j) => s + invPrice(j), 0);
  const vnd = usd * invoice.rate;
  const today = () => new Date().toISOString().slice(0, 10);

  const text = [
    `${invoice.number} — ${invoice.client}`,
    "",
    ...list.map((j) => `${j.jobCode}  ${j.jobName || "Untitled"}  ${fmtUSD(invPrice(j))}`),
    "",
    `Total jobs: ${list.length}`,
    `Total invoice: ${fmtUSD(usd)}`,
    `Exchange rate: ${invoice.rate.toLocaleString("vi-VN")}`,
    `Equivalent: ${fmtVND(vnd)}`,
    `Created: ${invoice.createdAt}`,
  ].join("\n");

  const th = { textAlign: "left", padding: "9px 11px", fontSize: 10.5, fontWeight: 700, letterSpacing: ".06em", color: T.faint, background: T.surface2, whiteSpace: "nowrap" };
  const td = { padding: "10px 11px", fontSize: 13, borderTop: `1px solid ${T.border}` };

  return (
    <Modal
      title={`${invoice.number} · ${invoice.client}`}
      icon={<Receipt size={17} color={T.accent} />}
      onClose={onClose}
      width={820}
      footer={
        <>
          <Btn variant="danger" onClick={() => onDelete(invoice)}><Trash2 size={14} /> Delete</Btn>
          <div style={{ flex: 1 }} />
          <Btn onClick={async () => { try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch {} }}>
            {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? "Copied" : "Copy"}
          </Btn>
          <Btn onClick={() => window.print()}><Printer size={14} /> Print / PDF</Btn>
        </>
      }
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div className="vt-noprint" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 12 }}>
          <ToggleRow
            label="Invoice sent" tone="info" on={!!invoice.sentAt} date={invoice.sentAt}
            onToggle={(v) => onUpdate({ ...invoice, sentAt: v ? today() : null, paidAt: v ? invoice.paidAt : null })}
          />
          <ToggleRow
            label="Payment received" tone="good" on={!!invoice.paidAt} date={invoice.paidAt} disabled={!invoice.sentAt}
            hint={!invoice.sentAt ? "Mark as sent first" : ""}
            onToggle={(v) => onUpdate({ ...invoice, paidAt: v ? today() : null })}
          />
        </div>

        <div style={{ border: `1px solid ${T.border}`, borderRadius: 10, overflow: "hidden" }}>
          <div className="vt-scroll" style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 620 }}>
              <thead>
                <tr><th style={th}>Client</th><th style={th}>Job name</th><th style={th}>Job code</th><th style={th}>Video note</th><th style={th}>Done link</th><th style={{ ...th, textAlign: "right" }}>Price</th></tr>
              </thead>
              <tbody>
                {list.map((j) => (
                  <tr key={j.jobCode}>
                    <td style={td}><ClientBadge name={j.client} /></td>
                    <td style={{ ...td, maxWidth: 180, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{j.jobName || "Untitled"}</td>
                    <td style={{ ...td, fontFamily: MONO, fontSize: 12 }}>{j.jobCode}</td>
                    <td style={{ ...td, maxWidth: 170, color: T.muted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{j.videoNote || "—"}</td>
                    <td style={td}>{j.outputLink ? <a href={j.outputLink} target="_blank" rel="noreferrer" style={{ color: T.info, display: "inline-flex", gap: 4, alignItems: "center" }}><Link2 size={12} /> Open</a> : <span style={{ color: T.faint }}>—</span>}</td>
                    <td style={{ ...td, textAlign: "right", fontFamily: MONO, fontWeight: 700 }}>{fmtUSD(invPrice(j))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <Card style={{ background: T.surface2 }}>
          {[
            ["Total jobs", String(list.length)],
            ["Total invoice", fmtUSD(usd)],
            ["PayPal exchange rate", invoice.rate.toLocaleString("vi-VN")],
            ["Equivalent", fmtVND(vnd)],
            ["Created", invoice.createdAt],
          ].map(([k, v], i) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderTop: i ? `1px solid ${T.border}` : "none" }}>
              <span style={{ color: T.muted, fontSize: 13 }}>{k}</span>
              <span style={{ fontFamily: MONO, fontWeight: k === "Total invoice" ? 800 : 600, color: k === "Total invoice" ? T.accent : T.text }}>{v}</span>
            </div>
          ))}
        </Card>
      </div>
    </Modal>
  );
}

export function ToggleRow({ label, tone, on, date, onToggle, disabled, hint }) {
  const T = useT();
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 11, padding: "11px 13px", borderRadius: 10,
      border: `1px solid ${on ? T[tone] + "55" : T.border}`, background: on ? `${T[tone]}12` : "transparent",
      opacity: disabled ? 0.55 : 1,
    }}>
      <input type="checkbox" checked={on} disabled={disabled} onChange={(e) => onToggle(e.target.checked)} style={{ width: 16, height: 16 }} />
      <div style={{ minWidth: 0 }}>
        <div style={{ fontWeight: 650, fontSize: 13.5 }}>{label}</div>
        <div style={{ fontSize: 12, color: T.faint }}>{on ? date : hint || "Not yet"}</div>
      </div>
    </div>
  );
}
