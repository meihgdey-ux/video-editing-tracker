import { useState } from "react";
import { useT, MONO } from "../lib/theme.js";
import { budgetTotal, monthKey, weekKey, fmtVND, fmtUSD } from "../lib/domain.js";
import { Card, Stat, Avatar } from "./primitives.jsx";
import { Empty } from "./Dashboard.jsx";

export function editorRows(jobs, name) {
  const m = {};
  jobs.filter((j) => j.assignedEditor === name).forEach((j) => {
    const d = j.date || "—";
    m[d] = m[d] || { jobs: 0, vnd: 0 };
    m[d].jobs++; m[d].vnd += budgetTotal(j);
  });
  return Object.entries(m).sort(([a], [b]) => b.localeCompare(a));
}

export function EditorsView({ jobs, rate, editors }) {
  const T = useT();
  const [open, setOpen] = useState(editors[0] || "");
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(210px,1fr))", gap: 12 }}>
        {editors.map((e) => {
          const mine = jobs.filter((j) => j.assignedEditor === e);
          const vnd = mine.reduce((s, j) => s + budgetTotal(j), 0);
          return (
            <Card key={e} style={{ cursor: "pointer", borderColor: open === e ? T.accent : T.border }}>
              <div onClick={() => setOpen(e)}>
                <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                  <Avatar name={e} size={32} />
                  <div>
                    <div style={{ fontWeight: 650 }}>{e}</div>
                    <div style={{ fontSize: 12, color: T.faint }}>{mine.length} jobs</div>
                  </div>
                </div>
                <div style={{ fontFamily: MONO, fontSize: 20, fontWeight: 700, marginTop: 10 }}>{fmtVND(vnd)}</div>
                <div style={{ fontFamily: MONO, fontSize: 12, color: T.muted }}>≈ {fmtUSD(vnd / rate)}</div>
              </div>
            </Card>
          );
        })}
      </div>
      <EarningsTable jobs={jobs} name={open} rate={rate} />
    </div>
  );
}

export function EarningsView({ jobs, me, rate }) {
  return <EarningsTable jobs={jobs} name={me} rate={rate} />;
}

export function EarningsTable({ jobs, name, rate }) {
  const T = useT();
  const rows = editorRows(jobs, name);
  const mine = jobs.filter((j) => j.assignedEditor === name);
  const total = mine.reduce((s, j) => s + budgetTotal(j), 0);

  const now = new Date();
  const thisWeek = weekKey(now.toISOString().slice(0, 10));
  const weekTotal = mine.filter((j) => j.date && weekKey(j.date) === thisWeek).reduce((s, j) => s + budgetTotal(j), 0);
  const monthTotal = mine.filter((j) => monthKey(j.date) === now.toISOString().slice(0, 7)).reduce((s, j) => s + budgetTotal(j), 0);
  const yearTotal = mine.filter((j) => (j.date || "").startsWith(String(now.getFullYear()))).reduce((s, j) => s + budgetTotal(j), 0);

  const th = { textAlign: "left", padding: "10px 12px", fontSize: 10.5, fontWeight: 700, letterSpacing: ".07em", color: T.faint, background: T.surface2 };
  const td = { padding: "10px 12px", fontSize: 13 };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))", gap: 12 }}>
        <Stat label="This week" value={fmtVND(weekTotal)} />
        <Stat label="This month" value={fmtVND(monthTotal)} />
        <Stat label="This year" value={fmtVND(yearTotal)} />
        <Stat label="Selected period" value={fmtVND(total)} sub={`≈ ${fmtUSD(total / rate)}`} tone="accent" />
      </div>
      <Card pad={0} style={{ overflow: "hidden" }}>
        <div style={{ padding: "13px 16px", borderBottom: `1px solid ${T.border}`, display: "flex", alignItems: "center", gap: 9 }}>
          <Avatar name={name} size={26} /><span style={{ fontWeight: 650 }}>{name}</span>
          <span style={{ color: T.faint, fontSize: 12.5 }}>· {mine.length} jobs</span>
        </div>
        {rows.length === 0 ? (
          <Empty title="Nothing earned in this period" body="Pick another month, or check back once jobs are assigned." />
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead><tr><th style={th}>Date</th><th style={th}>Jobs</th><th style={{ ...th, textAlign: "right" }}>VNĐ</th><th style={{ ...th, textAlign: "right" }}>USD</th></tr></thead>
            <tbody>
              {rows.map(([d, v]) => (
                <tr key={d} style={{ borderTop: `1px solid ${T.border}` }}>
                  <td style={{ ...td, fontFamily: MONO, fontSize: 12, color: T.muted }}>{d}</td>
                  <td style={td}>{v.jobs}</td>
                  <td style={{ ...td, textAlign: "right", fontFamily: MONO, fontWeight: 650 }}>{fmtVND(v.vnd)}</td>
                  <td style={{ ...td, textAlign: "right", fontFamily: MONO, color: T.muted }}>{fmtUSD(v.vnd / rate)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}
