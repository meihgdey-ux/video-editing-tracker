import { useState, useMemo } from "react";
import { TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { useT, SANS, MONO } from "../lib/theme.js";
import { STATUSES, statusTone, invPrice, budgetTotal, monthKey, monthName, weekKey, fmtVND, fmtUSD } from "../lib/domain.js";
import { Card, Stat, Pill, ClientBadge, Avatar } from "./primitives.jsx";

export function Dashboard({ jobs, invoices, rate, month }) {
  const T = useT();
  const [grain, setGrain] = useState("day");

  const counts = useMemo(() => {
    const c = {};
    STATUSES.forEach((s) => (c[s] = 0));
    jobs.forEach((j) => (c[j.status] = (c[j.status] || 0) + 1));
    return c;
  }, [jobs]);

  const revUSD = jobs.reduce((s, j) => s + invPrice(j), 0);
  const payoutVND = jobs.reduce((s, j) => s + budgetTotal(j), 0);

  const chart = useMemo(() => {
    const m = {};
    jobs.forEach((j) => {
      if (!j.date) return;
      const k = grain === "day" ? j.date : grain === "week" ? weekKey(j.date) : monthKey(j.date);
      m[k] = (m[k] || 0) + invPrice(j);
    });
    return Object.entries(m).sort(([a], [b]) => a.localeCompare(b)).slice(-14)
      .map(([k, v]) => ({ k: grain === "month" ? k.slice(2) : k.slice(5), usd: Math.round(v * 100) / 100 }));
  }, [jobs, grain]);

  const byGroup = (key) => {
    const m = {};
    jobs.forEach((j) => {
      const g = j[key];
      if (!g) return;
      m[g] = m[g] || { jobs: 0, usd: 0, vnd: 0 };
      m[g].jobs++; m[g].usd += invPrice(j); m[g].vnd += budgetTotal(j);
    });
    return Object.entries(m).sort((a, b) => b[1].usd - a[1].usd || b[1].vnd - a[1].vnd);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(170px,1fr))", gap: 12 }}>
        <Stat label="Total jobs" value={jobs.length} sub={month === "ALL" ? "All months" : monthName(month)} />
        <Stat label="Revenue (USD)" value={fmtUSD(revUSD)} sub="Invoice price to clients" tone="good" />
        <Stat label="Revenue (VNĐ)" value={fmtVND(revUSD * rate)} sub={`Rate ${rate.toLocaleString("vi-VN")}`} />
        <Stat label="Editor payout" value={fmtVND(payoutVND)} sub="Total budget" tone="warn" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(118px,1fr))", gap: 10 }}>
        {STATUSES.map((s) => (
          <Card key={s} pad={12}>
            <Pill tone={statusTone[s]}>{s}</Pill>
            <div style={{ fontFamily: MONO, fontSize: 21, fontWeight: 700, marginTop: 8 }}>{counts[s]}</div>
          </Card>
        ))}
      </div>

      <Card>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14, flexWrap: "wrap", gap: 8 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontWeight: 650 }}>
            <TrendingUp size={16} color={T.accent} /> Revenue (USD)
          </div>
          <div style={{ display: "flex", background: T.surface2, borderRadius: 8, padding: 3, gap: 2 }}>
            {["day", "week", "month"].map((g) => (
              <button key={g} onClick={() => setGrain(g)} style={{
                padding: "5px 12px", borderRadius: 6, border: "none", cursor: "pointer", fontFamily: SANS,
                fontSize: 12, fontWeight: 650, textTransform: "capitalize",
                background: grain === g ? T.surface : "transparent", color: grain === g ? T.text : T.muted,
              }}>{g}</button>
            ))}
          </div>
        </div>
        {chart.length === 0 ? (
          <Empty title="No revenue yet" body="Add an invoice price to a job and it shows up here." />
        ) : (
          <div style={{ height: 230 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} margin={{ top: 4, right: 4, left: -18, bottom: 0 }}>
                <CartesianGrid strokeDasharray="2 4" stroke={T.border} vertical={false} />
                <XAxis dataKey="k" tick={{ fill: T.faint, fontSize: 11, fontFamily: MONO }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: T.faint, fontSize: 11, fontFamily: MONO }} axisLine={false} tickLine={false} />
                <Tooltip
                  cursor={{ fill: `${T.accent}12` }}
                  contentStyle={{ background: T.raised, border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 12, fontFamily: SANS, color: T.text }}
                  formatter={(v) => [fmtUSD(v), "Revenue"]}
                />
                <Bar dataKey="usd" fill={T.accent} radius={[4, 4, 0, 0]} maxBarSize={38} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))", gap: 12 }}>
        <BreakdownCard title="By client" rows={byGroup("client")} render={(n) => <ClientBadge name={n} />} rate={rate} />
        <BreakdownCard title="By editor" rows={byGroup("assignedEditor")} render={(n) => (
          <span style={{ display: "flex", alignItems: "center", gap: 8 }}><Avatar name={n} size={22} />{n}</span>
        )} rate={rate} showVnd />
      </div>
    </div>
  );
}

export function BreakdownCard({ title, rows, render, showVnd }) {
  const T = useT();
  return (
    <Card>
      <div style={{ fontWeight: 650, marginBottom: 10 }}>{title}</div>
      {rows.length === 0 ? <div style={{ color: T.faint, fontSize: 13 }}>Nothing here yet.</div> : (
        <div style={{ display: "flex", flexDirection: "column" }}>
          {rows.map(([name, v]) => (
            <div key={name} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderTop: `1px solid ${T.border}` }}>
              <div style={{ flex: 1, minWidth: 0 }}>{render(name)}</div>
              <span style={{ fontSize: 12, color: T.faint, fontFamily: MONO }}>{v.jobs} jobs</span>
              <span style={{ fontFamily: MONO, fontWeight: 700, minWidth: 78, textAlign: "right" }}>
                {showVnd ? fmtVND(v.vnd) : fmtUSD(v.usd)}
              </span>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

export function Empty({ title, body, action }) {
  const T = useT();
  return (
    <div style={{ padding: "44px 20px", textAlign: "center" }}>
      <div style={{ fontWeight: 650, marginBottom: 4 }}>{title}</div>
      <div style={{ color: T.muted, fontSize: 13, marginBottom: action ? 14 : 0 }}>{body}</div>
      {action}
    </div>
  );
}
