import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { useT, SANS, MONO } from "../lib/theme.js";

export function Pill({ tone = "faint", children, dot = true, size = "sm" }) {
  const T = useT();
  const c = T[tone] || T.faint;
  return (
    <span
      style={{
        display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap",
        fontFamily: MONO, fontSize: size === "sm" ? 11 : 12, fontWeight: 600, letterSpacing: ".02em",
        color: c, background: `${c}1A`, border: `1px solid ${c}44`, borderRadius: 999,
        padding: size === "sm" ? "3px 9px" : "5px 11px",
      }}
    >
      {dot && <span style={{ width: 5, height: 5, borderRadius: "50%", background: c }} />}
      {children}
    </span>
  );
}

const PALETTE = ["#E8735A", "#4FA3E0", "#7BC77B", "#C58BE0", "#E0A93D", "#4FC4C0", "#E07BA8", "#8B9BE0"];
export const hashColor = (s) => {
  if (!s) return "#888";
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return PALETTE[h % PALETTE.length];
};

export function ClientBadge({ name }) {
  const T = useT();
  if (!name) return <span style={{ color: T.faint }}>—</span>;
  const c = hashColor(name);
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", fontSize: 12.5, fontWeight: 600, whiteSpace: "nowrap",
      color: c, background: `${c}20`, border: `1px solid ${c}44`, borderRadius: 6, padding: "3px 9px",
    }}>
      {name}
    </span>
  );
}

export function Avatar({ name, size = 26 }) {
  const T = useT();
  if (!name) return <span style={{ width: size, height: size, borderRadius: "50%", border: `1px dashed ${T.borderStrong}`, display: "inline-block", flexShrink: 0 }} />;
  const c = hashColor(name);
  const ini = name.split(/[\s._-]+/).filter(Boolean).slice(0, 2).map((p) => p[0]).join("").toUpperCase();
  return (
    <span title={name} style={{
      width: size, height: size, borderRadius: "50%", background: c, color: "#10141A", flexShrink: 0,
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      fontSize: size * 0.38, fontWeight: 800, fontFamily: MONO,
    }}>{ini}</span>
  );
}

export function Btn({ variant = "ghost", children, style, ...p }) {
  const T = useT();
  const base = {
    display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6,
    fontFamily: SANS, fontSize: 13, fontWeight: 600, borderRadius: 8, padding: "8px 13px",
    cursor: p.disabled ? "not-allowed" : "pointer", opacity: p.disabled ? 0.5 : 1,
    transition: "background .12s, border-color .12s", whiteSpace: "nowrap",
  };
  const v = {
    primary: { background: T.accent, color: T.accentText, border: "none" },
    ghost: { background: "transparent", color: T.text, border: `1px solid ${T.border}` },
    subtle: { background: "transparent", color: T.muted, border: "none" },
    danger: { background: "transparent", color: T.bad, border: `1px solid ${T.bad}55` },
  }[variant];
  return <button {...p} style={{ ...base, ...v, ...style }}>{children}</button>;
}

export function inputStyle(T) {
  return {
    width: "100%", background: T.surface2, border: `1px solid ${T.border}`, borderRadius: 8,
    color: T.text, padding: "9px 11px", fontSize: 13.5, fontFamily: SANS, outline: "none",
  };
}
export const TextInput = (p) => { const T = useT(); return <input {...p} style={{ ...inputStyle(T), ...(p.style || {}) }} />; };
export const TextArea = (p) => { const T = useT(); return <textarea {...p} style={{ ...inputStyle(T), minHeight: 80, resize: "vertical", ...(p.style || {}) }} />; };
export function Select({ children, ...p }) {
  const T = useT();
  return (
    <select {...p} style={{
      ...inputStyle(T), appearance: "none", WebkitAppearance: "none", paddingRight: 28, cursor: "pointer",
      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%23888' stroke-width='1.5' fill='none'/%3E%3C/svg%3E")`,
      backgroundRepeat: "no-repeat", backgroundPosition: "right 10px center",
      ...(p.style || {}),
    }}>{children}</select>
  );
}
export function Field({ label, children, span }) {
  const T = useT();
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, gridColumn: span ? `span ${span}` : undefined, minWidth: 0 }}>
      <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".06em", textTransform: "uppercase", color: T.muted }}>{label}</span>
      {children}
    </label>
  );
}

export function Card({ children, style, pad = 16 }) {
  const T = useT();
  return <div style={{ background: T.surface, border: `1px solid ${T.border}`, borderRadius: 12, padding: pad, ...style }}>{children}</div>;
}

export function Stat({ label, value, sub, tone }) {
  const T = useT();
  return (
    <Card>
      <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".06em", textTransform: "uppercase", color: T.muted }}>{label}</div>
      <div style={{ fontFamily: MONO, fontSize: 24, fontWeight: 700, marginTop: 6, color: tone ? T[tone] : T.text, letterSpacing: "-.02em" }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: T.faint, marginTop: 3 }}>{sub}</div>}
    </Card>
  );
}

export function Skeleton({ h = 16, w = "100%", r = 6 }) {
  const T = useT();
  return (
    <div style={{ height: h, width: w, borderRadius: r, background: T.surface2, opacity: 0.7, animation: "vtPulse 1.4s ease-in-out infinite" }} />
  );
}

export function Modal({ title, icon, onClose, children, footer, width = 720 }) {
  const T = useT();
  useEffect(() => {
    const h = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 80, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div onClick={onClose} style={{ position: "absolute", inset: 0, background: "rgba(8,10,14,.6)", backdropFilter: "blur(2px)" }} />
      <div style={{
        position: "relative", width: `min(${width}px, 100%)`, maxHeight: "90vh", display: "flex", flexDirection: "column",
        background: T.bg, border: `1px solid ${T.border}`, borderRadius: 14, boxShadow: T.shadow, color: T.text, fontFamily: SANS,
        animation: "vtIn .16s ease-out",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "15px 18px", borderBottom: `1px solid ${T.border}` }}>
          <div style={{ display: "flex", alignItems: "center", gap: 9, fontWeight: 700, fontSize: 15 }}>{icon}{title}</div>
          <Btn variant="subtle" onClick={onClose} style={{ padding: 6 }}><X size={18} /></Btn>
        </div>
        <div style={{ padding: 18, overflowY: "auto", flex: 1 }}>{children}</div>
        {footer && <div style={{ padding: 14, borderTop: `1px solid ${T.border}`, display: "flex", gap: 9, justifyContent: "flex-end" }}>{footer}</div>}
      </div>
    </div>
  );
}
