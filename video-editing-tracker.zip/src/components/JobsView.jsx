import { useState, useMemo, Fragment } from "react";
import { Search, Plus, ChevronDown, ChevronRight, Link2, Download, Music, Film } from "lucide-react";
import { useT, SANS, MONO } from "../lib/theme.js";
import { STATUSES, budgetTotal, invPrice, fmtVND, fmtUSD } from "../lib/domain.js";
import { Card, Btn, TextInput, Select, ClientBadge, Avatar } from "./primitives.jsx";
import { Empty } from "./Dashboard.jsx";

export function StatusSelect({ value, onChange }) {
  const T = useT();
  const c = T[statusTone[value]] || T.faint;
  return (
    <select
      value={value}
      onClick={(e) => e.stopPropagation()}
      onChange={(e) => { e.stopPropagation(); onChange(e.target.value); }}
      style={{
        appearance: "none", WebkitAppearance: "none", cursor: "pointer",
        fontFamily: MONO, fontSize: 11.5, fontWeight: 650, color: c,
        background: `${c}1A`, border: `1px solid ${c}44`, borderRadius: 999, padding: "5px 22px 5px 11px",
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='9' height='5'%3E%3Cpath d='M1 1l3.5 3L8 1' stroke='%23999' stroke-width='1.4' fill='none'/%3E%3C/svg%3E")`,
        backgroundRepeat: "no-repeat", backgroundPosition: "right 9px center",
      }}
    >
      {STATUSES.map((s) => <option key={s} value={s} style={{ background: T.surface, color: T.text }}>{s}</option>)}
    </select>
  );
}

export function JobsView({ jobs, role, clients, onOpen, onStatus, onNew }) {
  const T = useT();
  const [q, setQ] = useState("");
  const [fClient, setFClient] = useState("ALL");
  const [fStatus, setFStatus] = useState("ALL");
  const [sortDesc, setSortDesc] = useState(true);
  const [expanded, setExpanded] = useState({});

  const rows = useMemo(() => {
    let r = jobs.filter((j) => {
      if (fClient !== "ALL" && j.client !== fClient) return false;
      if (fStatus !== "ALL" && j.status !== fStatus) return false;
      if (q.trim()) {
        const s = `${j.jobCode} ${j.client} ${j.jobName} ${j.instruction} ${j.assignedEditor}`.toLowerCase();
        if (!s.includes(q.toLowerCase().trim())) return false;
      }
      return true;
    });
    r.sort((a, b) => (a.date || "").localeCompare(b.date || "") * (sortDesc ? -1 : 1));
    return r;
  }, [jobs, q, fClient, fStatus, sortDesc]);

  const stickyCell = { position: "sticky", background: "inherit", zIndex: 1 };
  const th = {
    textAlign: "left", padding: "10px 12px", fontSize: 10.5, fontWeight: 700, letterSpacing: ".07em",
    color: T.faint, whiteSpace: "nowrap", background: T.surface2, position: "sticky", top: 0, zIndex: 2,
  };
  const td = { padding: "11px 12px", fontSize: 13, verticalAlign: "middle" };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <div style={{ position: "relative", flex: "1 1 200px", minWidth: 170 }}>
          <Search size={14} color={T.faint} style={{ position: "absolute", left: 11, top: 11 }} />
          <TextInput value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search code, client, note…" style={{ paddingLeft: 32 }} />
        </div>
        <Select value={fClient} onChange={(e) => setFClient(e.target.value)} style={{ width: 150 }}>
          <option value="ALL">All clients</option>
          {clients.map((c) => <option key={c}>{c}</option>)}
        </Select>
        <Select value={fStatus} onChange={(e) => setFStatus(e.target.value)} style={{ width: 150 }}>
          <option value="ALL">All statuses</option>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </Select>
        <Btn onClick={() => setSortDesc((v) => !v)}>Date {sortDesc ? "↓" : "↑"}</Btn>
      </div>

      <Card pad={0} style={{ overflow: "hidden" }}>
        {rows.length === 0 ? (
          <Empty
            title={jobs.length ? "No jobs match these filters" : "No jobs yet"}
            body={jobs.length ? "Clear a filter to see more." : role === "admin" ? "Create your first job to start tracking." : "Jobs assigned to you will show up here."}
            action={role === "admin" && !jobs.length ? <Btn variant="primary" onClick={onNew}><Plus size={15} /> New job</Btn> : null}
          />
        ) : (
          <div className="vt-scroll" style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 900 }}>
              <thead>
                <tr>
                  <th style={{ ...th, ...stickyCell, left: 0, width: 104, minWidth: 104 }}>Date</th>
                  <th style={{ ...th, ...stickyCell, left: 104, width: 116, minWidth: 116 }}>Client</th>
                  <th style={th}>Job code</th>
                  <th style={th}>Job / note</th>
                  <th style={th}>Links</th>
                  <th style={th}>Editor</th>
                  <th style={th}>Status</th>
                  <th style={{ ...th, textAlign: "right" }}>Budget</th>
                  {role === "admin" && <th style={{ ...th, textAlign: "right" }}>Invoice</th>}
                </tr>
              </thead>
              <tbody>
                {rows.map((j) => {
                  const open = expanded[j.jobCode];
                  return (
                    <Fragment key={j.jobCode}>
                      <tr className="vt-row" onClick={() => onOpen(j)}
                        style={{ borderTop: `1px solid ${T.border}`, cursor: "pointer", background: T.surface }}>
                        <td style={{ ...td, ...stickyCell, left: 0, width: 104, fontFamily: MONO, fontSize: 12, color: T.muted }}>{j.date}</td>
                        <td style={{ ...td, ...stickyCell, left: 104, width: 116 }}><ClientBadge name={j.client} /></td>
                        <td style={{ ...td, fontFamily: MONO, fontSize: 12, fontWeight: 650 }}>{j.jobCode}</td>
                        <td style={{ ...td, maxWidth: 240 }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                            <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                              {j.jobName || <span style={{ color: T.faint }}>Untitled</span>}
                            </span>
                            {j.instruction && (
                              <button onClick={(e) => { e.stopPropagation(); setExpanded((s) => ({ ...s, [j.jobCode]: !open })); }}
                                title={open ? "Hide instruction" : "Show instruction"}
                                style={{ background: "none", border: "none", cursor: "pointer", color: T.faint, padding: 2, display: "flex" }}>
                                {open ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                              </button>
                            )}
                          </div>
                        </td>
                        <td style={td}>
                          <div style={{ display: "flex", gap: 5 }} onClick={(e) => e.stopPropagation()}>
                            <IconLink href={j.inputLink} label="Input footage" tone="info" icon={Download} />
                            <IconLink href={j.sampleLink} label="Sample / reference" tone="violet" icon={Film} />
                            <IconLink href={j.musicLink} label="Music" tone="warn" icon={Music} />
                            <IconLink href={j.outputLink} label="Output" tone="good" icon={Link2} />
                          </div>
                        </td>
                        <td style={td}>
                          <span style={{ display: "flex", alignItems: "center", gap: 7 }}>
                            <Avatar name={j.assignedEditor} size={22} />
                            <span style={{ color: j.assignedEditor ? T.text : T.faint, fontSize: 12.5 }}>{j.assignedEditor || "Unassigned"}</span>
                          </span>
                        </td>
                        <td style={td}><StatusSelect value={j.status} onChange={(s) => onStatus(j.jobCode, s)} /></td>
                        <td style={{ ...td, textAlign: "right", fontFamily: MONO, fontWeight: 650 }}>{fmtVND(budgetTotal(j))}</td>
                        {role === "admin" && (
                          <td style={{ ...td, textAlign: "right", fontFamily: MONO, fontWeight: 650, color: invPrice(j) ? T.good : T.faint }}>
                            {invPrice(j) ? fmtUSD(invPrice(j)) : "—"}
                          </td>
                        )}
                      </tr>
                      {open && (
                        <tr style={{ background: T.surface2 }}>
                          <td colSpan={role === "admin" ? 9 : 8} style={{ padding: "12px 16px", borderTop: `1px solid ${T.border}` }}>
                            <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: ".06em", color: T.faint, marginBottom: 5 }}>INSTRUCTION</div>
                            <div style={{ whiteSpace: "pre-wrap", fontSize: 13, color: T.text }}>{j.instruction}</div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

export function IconLink({ href, label, tone, icon: Icon = Link2 }) {
  const T = useT();
  if (!href) return <span style={{ width: 24, height: 24, display: "grid", placeItems: "center", color: T.faint, opacity: .35 }}>–</span>;
  return (
    <a href={href} target="_blank" rel="noreferrer" title={label} style={{
      width: 24, height: 24, borderRadius: 6, display: "grid", placeItems: "center",
      color: T[tone], background: `${T[tone]}18`, border: `1px solid ${T[tone]}3A`,
    }}><Icon size={12} /></a>
  );
}
