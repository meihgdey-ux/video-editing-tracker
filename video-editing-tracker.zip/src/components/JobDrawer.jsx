import { useState } from "react";
import { X, Plus, Trash2, Link2 } from "lucide-react";
import { useT, SANS, MONO } from "../lib/theme.js";
import { STATUSES, JOB_TYPES, statusTone, newBudgetLine, budgetTotal, invPrice, fmtVND, fmtUSD } from "../lib/domain.js";
import { Btn, TextInput, TextArea, Select, Field, Pill, ClientBadge, Avatar } from "./primitives.jsx";

export function JobDrawer({ drawer, role, clients, editors, rates, rate, existing, onClose, onSave, onDelete }) {
  const T = useT();
  const isNew = drawer.mode === "new";
  const [form, setForm] = useState(drawer.job);
  const [editing, setEditing] = useState(isNew);
  const [more, setMore] = useState(!isNew);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const canSave = form.jobCode && form.client && (!isNew || !existing.includes(form.jobCode));
  const readOnly = role !== "admin";

  const updLine = (id, patch) => setForm((f) => ({ ...f, budgetItems: f.budgetItems.map((b) => (b.id === id ? { ...b, ...patch } : b)) }));

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 80, display: "flex", justifyContent: "flex-end" }}>
      <div onClick={onClose} style={{ position: "absolute", inset: 0, background: "rgba(8,10,14,.6)" }} />
      <div className="vt-scroll" style={{
        position: "relative", width: "min(520px,100%)", height: "100%", overflowY: "auto",
        background: T.bg, borderLeft: `1px solid ${T.border}`, color: T.text, fontFamily: SANS,
      }}>
        <div style={{ position: "sticky", top: 0, zIndex: 2, background: T.bg, borderBottom: `1px solid ${T.border}`, padding: "15px 18px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, fontFamily: MONO }}>{isNew ? "New job" : form.jobCode}</div>
            <div style={{ fontSize: 12, color: T.faint }}>{isNew ? "Only code and client are required" : editing ? "Editing" : form.jobName || "Job details"}</div>
          </div>
          <Btn variant="subtle" onClick={onClose} style={{ padding: 6 }}><X size={18} /></Btn>
        </div>

        <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 18 }}>
          {!editing ? (
            <JobRead form={form} role={role} rate={rate} />
          ) : (
            <>
              <Sect title="Required">
                <Grid2>
                  <Field label="Job code"><TextInput value={form.jobCode} onChange={set("jobCode")} disabled={!isNew} /></Field>
                  <Field label="Client">
                    <Select value={form.client} onChange={set("client")}>
                      <option value="">Select a client</option>
                      {clients.map((c) => <option key={c}>{c}</option>)}
                    </Select>
                  </Field>
                </Grid2>
              </Sect>

              <Sect title="Assignment">
                <Grid2>
                  <Field label="Date"><TextInput type="date" value={form.date} onChange={set("date")} /></Field>
                  <Field label="Editor">
                    <Select value={form.assignedEditor} onChange={set("assignedEditor")}>
                      <option value="">Unassigned</option>
                      {editors.map((e) => <option key={e}>{e}</option>)}
                    </Select>
                  </Field>
                  <Field label="Status">
                    <Select value={form.status} onChange={set("status")}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</Select>
                  </Field>
                  <Field label="Job name"><TextInput value={form.jobName} onChange={set("jobName")} placeholder="4364 Corso Venetia Blvd" /></Field>
                </Grid2>
              </Sect>

              {!more && <Btn onClick={() => setMore(true)} style={{ borderStyle: "dashed", justifyContent: "flex-start", color: T.muted }}>Add details, links and pricing</Btn>}

              {more && (
                <>
                  <Sect title="Brief">
                    <Grid2>
                      {role === "admin" && <Field label="CS name"><TextInput value={form.csName} onChange={set("csName")} /></Field>}
                      {role === "admin" && (
                        <Field label="Job type">
                          <Select value={form.jobType} onChange={set("jobType")}>{JOB_TYPES.map((t) => <option key={t}>{t}</option>)}</Select>
                        </Field>
                      )}
                      <Field label="Input link" span={2}><TextInput value={form.inputLink} onChange={set("inputLink")} placeholder="https:// — raw footage" /></Field>
                      <Field label="Sample link"><TextInput value={form.sampleLink} onChange={set("sampleLink")} placeholder="https:// — reference video" /></Field>
                      <Field label="Music link"><TextInput value={form.musicLink} onChange={set("musicLink")} placeholder="https:// — track or folder" /></Field>
                      <Field label="Instruction" span={2}><TextArea value={form.instruction} onChange={set("instruction")} /></Field>
                    </Grid2>
                  </Sect>

                  <Sect title="Output">
                    <Grid2>
                      <Field label="Output video"><TextInput value={form.outputVideo} onChange={set("outputVideo")} placeholder="1min20" /></Field>
                      <Field label="Output link"><TextInput value={form.outputLink} onChange={set("outputLink")} placeholder="https://" /></Field>
                      <Field label="Video note" span={2}><TextInput value={form.videoNote} onChange={set("videoNote")} placeholder="Shown on the client invoice" /></Field>
                    </Grid2>
                  </Sect>

                  <Sect title={`Budget · editor pay${readOnly ? " (read only)" : ""}`}>
                    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                      {form.budgetItems.map((b) => (
                        <div key={b.id} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <Select value={b.label} disabled={readOnly} onChange={(e) => updLine(b.id, { label: e.target.value, amount: rates.find((r) => r.label === e.target.value)?.price ?? 0 })} style={{ flex: 2 }}>
                            {rates.map((c) => <option key={c.label}>{c.label}</option>)}
                          </Select>
                          <TextInput type="number" value={b.amount} disabled={readOnly} onChange={(e) => updLine(b.id, { amount: e.target.value })} style={{ flex: 1 }} />
                          {!readOnly && form.budgetItems.length > 1 && (
                            <Btn variant="subtle" onClick={() => setForm((f) => ({ ...f, budgetItems: f.budgetItems.filter((x) => x.id !== b.id) }))} style={{ padding: 5 }}>
                              <X size={14} />
                            </Btn>
                          )}
                        </div>
                      ))}
                      {!readOnly && (
                        <Btn onClick={() => setForm((f) => ({ ...f, budgetItems: [...f.budgetItems, newBudgetLine(rates)] }))} style={{ alignSelf: "flex-start", borderStyle: "dashed", color: T.muted }}>
                          <Plus size={14} /> Add line
                        </Btn>
                      )}
                      <div style={{ display: "flex", justifyContent: "space-between", paddingTop: 9, borderTop: `1px solid ${T.border}` }}>
                        <span style={{ fontSize: 12, fontWeight: 700, color: T.muted, letterSpacing: ".05em" }}>TOTAL</span>
                        <span style={{ fontFamily: MONO, fontWeight: 800, color: T.accent }}>{fmtVND(budgetTotal(form))}</span>
                      </div>
                    </div>
                  </Sect>

                  {role === "admin" && (
                    <Sect title="Invoice price · charged to client">
                      <Field label="Price (USD)">
                        <TextInput type="number" value={form.invoicePrice} onChange={set("invoicePrice")} placeholder="80" />
                      </Field>
                      {invPrice(form) > 0 && (
                        <div style={{ fontSize: 12.5, color: T.muted, fontFamily: MONO }}>≈ {fmtVND(invPrice(form) * rate)} at today's rate</div>
                      )}
                    </Sect>
                  )}
                </>
              )}
            </>
          )}
        </div>

        <div style={{ position: "sticky", bottom: 0, background: T.bg, borderTop: `1px solid ${T.border}`, padding: 15, display: "flex", gap: 9 }}>
          {!isNew && !editing && role === "admin" && <Btn variant="danger" onClick={() => onDelete(form.jobCode)}><Trash2 size={14} /> Delete</Btn>}
          <div style={{ flex: 1 }} />
          {editing ? (
            <>
              {!isNew && <Btn onClick={() => { setForm(drawer.job); setEditing(false); }}>Cancel</Btn>}
              <Btn variant="primary" disabled={!canSave} onClick={() => onSave(form)}>{isNew ? "Create job" : "Save changes"}</Btn>
            </>
          ) : (
            <Btn variant="primary" onClick={() => { setMore(true); setEditing(true); }}>Edit</Btn>
          )}
        </div>
      </div>
    </div>
  );
}

export const Grid2 = ({ children }) => <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>{children}</div>;

export function Sect({ title, children }) {
  const T = useT();
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: T.accent }}>{title}</div>
      {children}
    </div>
  );
}

export function Row({ label, value, link }) {
  const T = useT();
  if (!value) return null;
  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: 14, padding: "8px 0", borderBottom: `1px solid ${T.border}` }}>
      <span style={{ fontSize: 12.5, color: T.muted, flexShrink: 0 }}>{label}</span>
      {link
        ? <a href={value} target="_blank" rel="noreferrer" style={{ color: T.info, fontSize: 13, display: "flex", gap: 4, alignItems: "center" }}><Link2 size={12} /> Open</a>
        : <span style={{ fontSize: 13, textAlign: "right", wordBreak: "break-word" }}>{value}</span>}
    </div>
  );
}

export function JobRead({ form, role, rate }) {
  const T = useT();
  return (
    <>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <Pill tone={statusTone[form.status]} size="md">{form.status}</Pill>
        <ClientBadge name={form.client} />
        {form.assignedEditor && (
          <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
            <Avatar name={form.assignedEditor} size={22} />{form.assignedEditor}
          </span>
        )}
      </div>

      <Sect title="Job">
        <Row label="Date" value={form.date} />
        <Row label="Job name" value={form.jobName} />
        {role === "admin" && <Row label="CS name" value={form.csName} />}
        {role === "admin" && <Row label="Job type" value={form.jobType} />}
        <Row label="Input link" value={form.inputLink} link />
        <Row label="Sample link" value={form.sampleLink} link />
        <Row label="Music link" value={form.musicLink} link />
        <Row label="Output" value={form.outputVideo} />
        <Row label="Output link" value={form.outputLink} link />
      </Sect>

      {form.instruction && (
        <Sect title="Instruction">
          <div style={{ whiteSpace: "pre-wrap", fontSize: 13, background: T.surface, border: `1px solid ${T.border}`, borderRadius: 9, padding: 13 }}>
            {form.instruction}
          </div>
        </Sect>
      )}

      <Sect title="Budget">
        {form.budgetItems.filter((b) => parseFloat(b.amount)).map((b) => (
          <Row key={b.id} label={b.label} value={fmtVND(parseFloat(b.amount))} />
        ))}
        <div style={{ display: "flex", justifyContent: "space-between", paddingTop: 9 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: T.muted, letterSpacing: ".05em" }}>TOTAL</span>
          <span style={{ fontFamily: MONO, fontWeight: 800, color: T.accent }}>{fmtVND(budgetTotal(form))}</span>
        </div>
      </Sect>

      {role === "admin" && invPrice(form) > 0 && (
        <Sect title="Invoice price">
          <Row label="Charged to client" value={fmtUSD(invPrice(form))} />
          <Row label="Equivalent" value={fmtVND(invPrice(form) * rate)} />
        </Sect>
      )}
    </>
  );
}
